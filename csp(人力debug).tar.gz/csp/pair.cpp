#include "pair.h"
int mypair::GetFirst(void)
{
    return first;
}
int mypair::GetSecond(void)
{
    return second;
}
void mypair::SetFirst(int tempfirst)
{
    first = tempfirst;
}
void mypair::SetSecond(int tempsecond)
{
    second = tempsecond;
}